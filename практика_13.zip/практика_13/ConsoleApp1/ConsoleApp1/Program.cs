﻿using System;
using System.Globalization;

namespace ConsoleApp1 { 
public class Program
{
    // ТОЧКА ВХОДА - должен быть метод Main
    static void Main(string[] args)
    {
        Console.Title = "Сортировка пузырьком - Console App";

        Console.WriteLine("=== СОРТИРОВКА ПУЗЫРЬКОМ (BUBBLE SORT) ===");
        Console.WriteLine();

        // Ввод массива от пользователя
        double[] array = InputArrayFromConsole();

        // Проверка на пустой массив
        if (array == null || array.Length == 0)
        {
            Console.WriteLine("Массив пуст. Программа завершена.");
            Console.ReadKey();
            return;
        }

        Console.WriteLine("\nИсходный массив:");
        PrintArray(array);
        Console.WriteLine();

        // Создаем копию массива для работы
        double[] workingArray = (double[])array.Clone();

        // Вызов метода сортировки пузырьком
        BubbleSort(workingArray);

        Console.WriteLine("\nОтсортированный массив:");
        PrintArray(workingArray);
        Console.WriteLine();

        // Проверка корректности сортировки
        Console.WriteLine($"Проверка сортировки: {(IsSorted(workingArray) ? "Успешно" : "Ошибка")}");

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }

    // Все методы должны быть static
    public static void BubbleSort(double[] array)
    {
        int n = array.Length;
        Console.WriteLine("Процесс сортировки пузырьком:");

        for (int i = 0; i < n - 1; i++)
        {
            Console.WriteLine($"\n--- Проход {i + 1} ---");
            int swapsInPass = 0;

            for (int j = 0; j < n - i - 1; j++)
            {
                Console.Write($"Сравниваем [{array[j]:F2}] и [{array[j + 1]:F2}]");

                if (array[j] > array[j + 1])
                {
                    Swap(array, j, j + 1);
                    swapsInPass++;
                    Console.WriteLine(" -> МЕНЯЕМ");
                }
                else
                {
                    Console.WriteLine(" -> не меняем");
                }
            }

            Console.Write($"После прохода {i + 1}: ");
            PrintArray(array);

            if (swapsInPass == 0) break;
        }
    }

    public static void Swap(double[] array, int i, int j)
    {
        double temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public static bool IsSorted(double[] array)
    {
        for (int i = 0; i < array.Length - 1; i++)
        {
            if (array[i] > array[i + 1])
                return false;
        }
        return true;
    }

    // Остальные методы тоже должны быть static
    public static double[] InputArrayFromConsole()
    {
        Console.WriteLine("Введите элементы массива через пробел:");
        Console.WriteLine("Можно вводить целые и дробные числа (например: 3.14 2,5 -2.5 10 0.75)");
        Console.WriteLine("Используйте пробел как разделитель между числами!");
        string input = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(input))
        {
            Console.WriteLine("Ошибка: ввод пустой!");
            return new double[0];
        }

        try
        {
            char[] separators = new char[] { ' ', '\t' };
            string[] stringNumbers = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            double[] array = new double[stringNumbers.Length];
            int successfulConversions = 0;

            Console.WriteLine("\nПроцесс преобразования:");

            for (int i = 0; i < stringNumbers.Length; i++)
            {
                string numberString = stringNumbers[i].Trim();

                if (double.TryParse(numberString, NumberStyles.Any, CultureInfo.GetCultureInfo("ru-RU"), out double result))
                {
                    array[successfulConversions] = result;
                    successfulConversions++;
                    Console.WriteLine($"Успешно: '{numberString}' -> {result:F2}");
                }
                else if (double.TryParse(numberString, NumberStyles.Any, CultureInfo.InvariantCulture, out result))
                {
                    array[successfulConversions] = result;
                    successfulConversions++;
                    Console.WriteLine($"Успешно: '{numberString}' -> {result:F2}");
                }
                else
                {
                    Console.WriteLine($"Ошибка: '{numberString}' - не является числом");
                }
            }

            if (successfulConversions < stringNumbers.Length)
            {
                Console.WriteLine($"\nПредупреждение: только {successfulConversions} из {stringNumbers.Length} элементов были успешно преобразованы");
                Array.Resize(ref array, successfulConversions);
            }

            if (successfulConversions == 0)
            {
                Console.WriteLine("Не удалось преобразовать ни одного числа!");
                return new double[0];
            }

            return array;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            return new double[0];
        }
    }

    public static void PrintArray(double[] array)
    {
        Console.Write("[");

        for (int i = 0; i < array.Length; i++)
        {
            Console.Write($"{array[i]:F2}");
            if (i < array.Length - 1)
                Console.Write(", ");
        }

        Console.WriteLine("]");
    }
}
}