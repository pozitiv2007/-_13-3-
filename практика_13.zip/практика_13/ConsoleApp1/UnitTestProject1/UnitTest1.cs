﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ConsoleApp1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {


        [TestMethod]
        public void InputArrayFromConsole_WithInvalidCharacters_ReturnsEmptyArray()
        {
            
            //проверка: ввод символов
            Assert.IsFalse(double.TryParse("abc", out _));
            //проверка: ввод малого отрицательного и малого числа
            Assert.IsTrue(double.TryParse("-123", out _));
            Assert.IsTrue(double.TryParse("123", out _));
            //проверка: ввод большого отрицательного и большого числа
            Assert.IsTrue(double.TryParse("-99999999999999999", out _));
            Assert.IsTrue(double.TryParse("999999999999999999", out _));
            //проверка: ввод дробных маленьких чисел, отрицательных дробных маленьких чисел,
            Assert.IsTrue(double.TryParse("10,56", out _));
            Assert.IsTrue(double.TryParse("-10,56", out _));
            //проверка: ввод больших дробных отрицательных, больших дробных
            Assert.IsTrue(double.TryParse("-99999999999999999999999,999", out _));
            Assert.IsTrue(double.TryParse("99999999999999999999999,999", out _));

        }
        //Тесты по программе(по разным случаям)
        [TestMethod]
        public void TestBubbleSort_UnsortedArray()
        {
            // Arrange - Подготовка: создаем произвольный неотсортированный массив
            // Ожидаем правильно отсортированный массив
            double[] array = { 3.5, 1.2, 4.8, 2.1, 0.5 };
            double[] expected = { 0.5, 1.2, 2.1, 3.5, 4.8 }; 

            Program.BubbleSort(array);

            CollectionAssert.AreEqual(expected, array);
        }
        [TestMethod]
        public void TestBubbleSort_SmallNegativeFractionalNumbersArray()
        {
            //Arrange - малые отрицательные числа для сортировки
            double[] array = {
              -0.001, -0.000001, -0.0005, -0.000002,
                -0.0001, -0.00005, -0.00001, -0.000005
            };
            double[] expected = {
                 -0.001, -0.0005, -0.0001, -0.00005,
                -0.00001, -0.000005, -0.000002, -0.000001
            };

            // Act
            Program.BubbleSort(array);

            // Assert
            CollectionAssert.AreEqual(expected, array);
            Console.WriteLine("Большие отрицательные числа успешно отсортированы");
        }
        [TestMethod]
        public void TestBubbleSort_EmptyArray()
        {
            // Arrange - Подготовка: создаем пустой массив
            // Проверяем, не сломается ли программа на пустых данных
            double[] array = new double[0];
            double[] expected = new double[0];

            Program.BubbleSort(array);

            CollectionAssert.AreEqual(expected, array);
        }
        [TestMethod]
        public void TestBubbleSort_LargeNegativeFractionalNumbersArray()
        {
            //Arrange - большие отрицательные числа для сортировки
            double[] array = {
                -99999999999.89, -999999999999.67, -99999999999999.12, -9999999999999999.56,
                -99999999999999999.23, -9999999999989999.45, -99999999999799999.51, -99999999999599999.34
            };
            double[] expected = {
                -99999999999999999.23, -99999999999799999.51, -99999999999599999.34, -9999999999999999.56,
                -9999999999989999.45, -99999999999999.12, -999999999999.67, -99999999999.89
            };

            // Act
            Program.BubbleSort(array);

            // Assert
            CollectionAssert.AreEqual(expected, array);
            Console.WriteLine("Большие отрицательные числа успешно отсортированы");
        }
        [TestMethod]
        public void TestBubbleSort_LargeFractionalNumbersArray()
        {
            // Arrange - большие дробные числа для сортировки
            double[] array = {
                99999999999.89, 999999999999.67, 99999999999999.12, 9999999999999999.56,
                99999999999999999.23, 9999999999989999.45, 99999999999799999.51, 99999999999599999.34
            };
            double[] expected = {
                99999999999.89, 999999999999.67, 99999999999999.12, 9999999999989999.45,
                9999999999999999.56, 99999999999599999.34, 99999999999799999.51, 99999999999999999.23
            };

            // Act
            Program.BubbleSort(array);

            // Assert
            CollectionAssert.AreEqual(expected, array);
            Console.WriteLine("Большие дробные числа успешно отсортированы");
        }

       
        [TestMethod]
        public void TestBubbleSort_LargeNegativeNumbersArray()
        {
            // Arrange - большие отрицательные числа для сортировки
            double[] array = {
                -99999999999, -999999999999, -99999999999999, -9999999999999999,
                -99999999999999999, -9999999999989999, -99999999999799999, -99999999999599999
            };
            double[] expected = {
                -99999999999999999, -99999999999799999, -99999999999599999, -9999999999999999,
                -9999999999989999, -99999999999999, -999999999999, -99999999999
            };

            // Act
            Program.BubbleSort(array);

            // Assert
            CollectionAssert.AreEqual(expected, array);
            Console.WriteLine("Большие отрицательные числа успешно отсортированы");
        }
        [TestMethod]
        public void TestBubbleSort_LargeNumbersArray()
        {
            // Arrange - смесь больших чисел для сортировки
            double[] array = {
                99999999999, 999999999999, 99999999999999, 9999999999999999,
                99999999999999999, 9999999999989999, 99999999999799999, 99999999999599999
            };
            double[] expected = {
                99999999999, 999999999999, 99999999999999, 9999999999989999,
                9999999999999999, 99999999999599999, 99999999999799999, 99999999999999999
            };

            // Act
            Program.BubbleSort(array);

            // Assert
            CollectionAssert.AreEqual(expected, array);
            Console.WriteLine("Большие числа успешно отсортированы");
        }


    }

}
